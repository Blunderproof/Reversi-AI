# cs470-final

CS 470 Final Project
Clay Coleman | Eric Fortney

AI3 is our final version of the Reversi AI. To run:

`
cd /path/to/this/directory
javac *.java
java AI3 localhost 1 (or 2)
`

BACKROW BOYZ FOR THE WIN